# Camera Pose Auto-Sweep (Phase 1)

## Grid
z ∈ {0.25, 0.32, 0.40} (m)
pitch ∈ {0.0， 0.2， 0.4， 0.6, 0.8, 1.0， 1.2， 1.4， 1.57} (rad)
image: 640×480, horizontal_fov=1.047 rad, fps≈30

## Metrics (each run 10–15s)
- /perception/green_ratio_lane
- /perception/ground_ratio_lane
- /perception/crop_symmetry (abs)

## Table
| z (m) | pitch (rad)  | mean green_lane | mean ground_lane | mean (sym)  | Notes |
|-------|--------------|-----------------|------------------|-------------|-------|
| 0.25  |     0        |     0.0003      |       0.9997     |    0.0299   |       |
| 0.25  |     0.2      |     0.0359      |       0.9641     |    0.0019   |       |
| 0.25  |     0.4      |     0.0004      |       0.9996     |    0.0189   |       |
| 0.25  |     0.6      |     0.0003      |       0.9997     |    0.0018   |       |
| 0.25  |     0.8      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.25  |     1.0      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.25  |     1.2      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.25  |     1.4      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.25  |     1.57     |     0.0000      |       0.0000     |    0.0000   |       |

| 0.32  |     0        |     0.0003      |       0.9997     |    0.0016   |       |
| 0.32  |     0.2      |     0.0003      |       0.9997     |    0.0105   |       |
| 0.32  |     0.4      |     0.0004      |       0.9996     |    0.0086   |       |
| 0.32  |     0.6      |     0.0003      |       0.9997     |    0.0033   |       |
| 0.32  |     0.8      |     0.0000      |       0.0000     |    1.2313   |       |
| 0.32  |     1.0      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.32  |     1.2      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.32  |     1.4      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.32  |     1.57     |     0.0000      |       0.0000     |    0.0000   |       |

| 0.4   |     0.0      |     0.0078      |       0.9922     |    0.0020   |       |
| 0.4   |     0.2      |     0.0003      |       0.9997     |    0.0029   |       |
| 0.4   |     0.4      |     0.0004      |       0.9996     |    0.0013   |       |
| 0.4   |     0.6      |     0.0003      |       0.9997     |    0.0019   |       |
| 0.4   |     0.8      |     0.0002      |       0.9998     |    0.0060   |       |
| 0.4   |     1.0      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.4   |     1.2      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.4   |     1.4      |     0.0000      |       0.0000     |    0.0000   |       |
| 0.4   |     1.57     |     0.0000      |       0.0000     |    0.0000   |       |

pitch: 
0–0.6 "stable: lane band clear (green≈0, ground≈1), |sym| small"
≥0.8 "invalid: ROI not found / fallback; avoid steep pitch"
By default, z=0.32 and pitch=0.6 are used. Thresholds: green ≥ 0.30, ground ≥ 0.20 are satisfied. High pitch (≥ 0.8) is prone to failure and should be avoided.

| z (m) | pitch (rad)  | mean green_lane | mean ground_lane | mean (sym)  |                  Notes                     |
| 0.32  |     0.6      |      0.0003     |      0.9997      |    0.0033   | default pick: stable, lane band clean      |

| 0.40  |     0.4      |      0.0004     |      0.9996      |    0.0013   | equally good; slightly higher z tolerated  |
`4
| 0.25  |     0.2      |      0.0359     |      0.9641      |    0.0019   | more crops entering lane band (acceptable) |

## Procedure
1. Edit `crops.world` <link name="camera_link"> <pose>: set z, pitch for a candidate.
2. Rebuild & launch:
   - `colcon build && source install/setup.bash && ros2 launch row_follower row_follow_launch.py`
3. Record CSV for ~10–15s:
   - Terminal A: `ros2 topic echo /perception/green_ratio_lane --csv > green.csv`
   - Terminal B: `ros2 topic echo /perception/ground_ratio_lane --csv > ground.csv`
   - Terminal C: `ros2 topic echo /perception/crop_symmetry --csv > sym.csv`
4. Compute means (shell one-liners):
   - `awk -F, 'NR>1{s+=$2;n++} END{print s/n}' green.csv`   # mean green
   - `awk -F, 'NR>1{s+=$2;n++} END{print s/n}' ground.csv`  # mean ground
   - `awk -F, 'NR>1{a=$2; if(a<0) a=-a; s+=a; n++} END{print s/n}' sym.csv`  # mean |sym|
5. Fill the table row; pick the default pose meeting:
   - green ≥ 0.30, ground ≥ 0.20, and mean |sym| small.
6. Write the chosen (z, pitch) back into `crops.world`, add two screenshots:
   - rqt `/camera/image_raw` and `/perception/mask` at steady state.
7. Commit and tag:
   - `git add . && git commit -m "tools: camera sweep results"`
   - `git tag v0.2-camera-autoadapt && git push --tags`
