#!/usr/bin/env python3
import math
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from std_msgs.msg import Float32MultiArray, String, Float32, Int32


def clip(x, lo, hi):
    return lo if x < lo else (hi if x > hi else x)


class RowController(Node):
    """
    Everyday + recovery controller with real-time, interruptible micro-shifts.

    Modes
      - TRACK: normal following (crop_sym + heading + tiny side-balance term)
      - MICRO_SHIFT: when side imbalance or low confidence -> interruptible double-arc
        * phases: TURN1 -> TURN2 -> STRAIGHT -> EVAL (loop)
        * every phase watches side_delta / sym / confidence to early-exit or flip

    Inputs
      /row_errors: [lat_norm, heading]
      /perception/confidence
      /perception/conf_level
      /perception/side_delta   # (right_green - left_green), ~[-1, 1]

    Output
      /cmd_vel
      /controller/state_str
    """

    def __init__(self):
        super().__init__("row_controller")

        # ---------- TRACK base ----------
        self.declare_parameter("k_yaw", 2.0)         # heading error gain
        self.declare_parameter("k_lat", 1.0)         # lateral (lookahead-projected) gain
        self.declare_parameter("lookahead_norm", 1.0)
        self.declare_parameter("k_damp", 0.35)
        self.declare_parameter("sym_deadband", 0.01)

        self.declare_parameter("v_forward", 0.20)
        self.declare_parameter("v_min", 0.05)
        self.declare_parameter("omega_limit", 1.5)
        self.declare_parameter("omega_acc_limit", 2.5)

        self.declare_parameter("lat_alpha", 0.35)
        self.declare_parameter("head_alpha", 0.45)

        # **边带平衡项**：在 TRACK 里也微调，防止慢性漂移
        self.declare_parameter("k_side_track", 0.20)  # small! omega += k_side_track * side_delta

        # ---------- MICRO_SHIFT triggers ----------
        self.declare_parameter("ms_enter_side", 0.22)    # |side_delta| 进入阈值
        self.declare_parameter("ms_exit_side", 0.10)     # |side_delta| 退出阈值（迟滞）
        self.declare_parameter("ms_enter_conf", 0.30)    # 置信度过低也触发
        self.declare_parameter("ms_enter_sym", 0.28)     # |crop_sym| 太大也触发

        # ---------- MICRO_SHIFT shaping (自适应强度+可打断) ----------
        # baseline（对应 |side_delta|=1.0 的强度；实际会乘以 side_scale）
        self.declare_parameter("ms_v_frac", 0.20)        # v = v_forward * ms_v_frac
        self.declare_parameter("ms_omega_base", 0.30)    # rad/s (你的需求)
        self.declare_parameter("ms_turn_base", 1.00)     # s   (TURN1/2 每段)
        self.declare_parameter("ms_straight_base", 0.80) # s
        # 缩放：omega = base * side_scale，dur = base * (0.6 + 0.4*side_scale)
        self.declare_parameter("ms_min_scale", 0.33)     # 最低缩放，避免太弱
        self.declare_parameter("ms_max_cycles", 8)

        # 纠偏半强度（越界时）
        self.declare_parameter("ms_corr_scale", 0.5)     # 角速乘 0.5
        self.declare_parameter("ms_corr_turn_base", 1.00)
        self.declare_parameter("ms_corr_straight_base", 0.60)

        # 早停/回切阈值
        self.declare_parameter("ms_ok_conf", 0.45)       # 置信度恢复
        self.declare_parameter("ms_ok_sym", 0.06)        # 居中
        self.declare_parameter("ms_early_side_drop", 0.12)  # side_delta 降到此值下方可提前结束当前相位

        # read params
        gp = self.get_parameter
        self.k_yaw = float(gp("k_yaw").value)
        self.k_lat = float(gp("k_lat").value)
        self.lookahead_norm = max(0.3, float(gp("lookahead_norm").value))
        self.k_damp = float(gp("k_damp").value)
        self.sym_deadband = float(gp("sym_deadband").value)

        self.v_forward = float(gp("v_forward").value)
        self.v_min = float(gp("v_min").value)
        self.omega_limit = float(gp("omega_limit").value)
        self.omega_acc_limit = float(gp("omega_acc_limit").value)

        self.lat_alpha = float(gp("lat_alpha").value)
        self.head_alpha = float(gp("head_alpha").value)

        self.k_side_track = float(gp("k_side_track").value)

        self.ms_enter_side = float(gp("ms_enter_side").value)
        self.ms_exit_side = float(gp("ms_exit_side").value)
        self.ms_enter_conf = float(gp("ms_enter_conf").value)
        self.ms_enter_sym = float(gp("ms_enter_sym").value)

        self.ms_v_frac = float(gp("ms_v_frac").value)
        self.ms_omega_base = float(gp("ms_omega_base").value)
        self.ms_turn_base = float(gp("ms_turn_base").value)
        self.ms_straight_base = float(gp("ms_straight_base").value)
        self.ms_min_scale = float(gp("ms_min_scale").value)
        self.ms_max_cycles = int(gp("ms_max_cycles").value)

        self.ms_corr_scale = float(gp("ms_corr_scale").value)
        self.ms_corr_turn_base = float(gp("ms_corr_turn_base").value)
        self.ms_corr_straight_base = float(gp("ms_corr_straight_base").value)

        self.ms_ok_conf = float(gp("ms_ok_conf").value)
        self.ms_ok_sym = float(gp("ms_ok_sym").value)
        self.ms_early_side_drop = float(gp("ms_early_side_drop").value)

        # subs / pubs
        self.sub_err = self.create_subscription(Float32MultiArray, "/row_errors", self.cb_err, 10)
        self.sub_conf = self.create_subscription(Float32, "/perception/confidence", self.cb_conf, 10)
        self.sub_level = self.create_subscription(Int32, "/perception/conf_level", self.cb_level, 10)
        self.sub_side = self.create_subscription(Float32, "/perception/side_delta", self.cb_side, 10)

        self.pub_cmd = self.create_publisher(Twist, "/cmd_vel", 10)
        self.pub_state = self.create_publisher(String, "/controller/state_str", 10)

        # state
        self.omega_prev = 0.0
        self.last_time = self.get_clock().now()

        self.lat_f = 0.0
        self.head_f = 0.0
        self.side_delta = 0.0
        self.conf = 1.0

        self.mode = "TRACK"

        # micro-shift internals
        self.ms_dir = 0          # +1 左移（右多），-1 右移（左多）
        self.ms_phase = "TURN1"  # TURN1/2/STRAIGHT/EVAL 以及 CORR_T1/2/CORR_ST
        self.ms_t0 = self.get_clock().now()
        self.ms_cycles = 0
        self.ms_side_scale = 1.0
        self.ms_turn_dur = 1.0
        self.ms_straight_dur = 0.8
        self.ms_omega = 0.3

    # ====== callbacks ======
    def cb_conf(self, msg: Float32):
        self.conf = float(msg.data)

    def cb_level(self, msg: Int32):
        pass

    def cb_side(self, msg: Float32):
        self.side_delta = float(msg.data)

    # ====== main ======
    def cb_err(self, msg: Float32MultiArray):
        if len(msg.data) < 2:
            return
        lat_n = float(msg.data[0])   # [-0.5, 0.5]
        head  = float(msg.data[1])

        # filters
        if abs(lat_n) < self.sym_deadband:
            lat_n = 0.0
        a_lat  = clip(self.lat_alpha, 0.0, 1.0)
        a_head = clip(self.head_alpha, 0.0, 1.0)
        self.lat_f  = (1.0 - a_lat)  * self.lat_f  + a_lat  * lat_n
        self.head_f = (1.0 - a_head) * self.head_f + a_head * head

        now = self.get_clock().now()
        dt = (now - self.last_time).nanoseconds * 1e-9
        self.last_time = now
        if dt <= 0.0 or dt > 0.5:
            dt = 0.05

        # ---- mode selection ----
        if self.mode == "TRACK":
            if (abs(self.side_delta) >= self.ms_enter_side) or (self.conf < self.ms_enter_conf) or (abs(self.lat_f) >= self.ms_enter_sym):
                self._enter_micro_shift(trigger="enter")
        else:  # MICRO_SHIFT
            # 平衡/恢复 → 退出
            if (abs(self.side_delta) <= self.ms_exit_side and self.conf >= self.ms_ok_conf) or (abs(self.lat_f) <= self.ms_ok_sym and self.conf >= self.ms_ok_conf):
                self._enter_track()

        # ---- step ----
        if self.mode == "TRACK":
            tw = self._step_track(dt)
        else:
            tw = self._step_micro_shift(dt)

        self.pub_cmd.publish(tw)
        self.pub_state.publish(String(
            data=f"mode={self.mode} phase={self.ms_phase if self.mode!='TRACK' else '-'} "
                 f"v={tw.linear.x:.3f} omega={tw.angular.z:.3f} "
                 f"lat={self.lat_f:.3f} head={self.head_f:.3f} side={self.side_delta:.3f} "
                 f"conf={self.conf:.2f} cycles={self.ms_cycles} scale={self.ms_side_scale:.2f}"
        ))

    # ====== TRACK ======
    def _step_track(self, dt):
        Ld = max(0.5, self.lookahead_norm)
        h_lat = math.atan2(self.lat_f, Ld)
        h_des = h_lat

        # 基本 PD + 阻尼
        head_err = h_des - self.head_f
        omega = self.k_yaw * head_err + self.k_lat * h_des - self.k_damp * self.omega_prev

        # **边带平衡项**（小系数，实时纠偏；右多(+)→左转(+)）
        omega += self.k_side_track * self.side_delta

        # limits
        omega = clip(omega, -self.omega_limit, self.omega_limit)
        max_step = self.omega_acc_limit * dt
        omega = clip(omega, self.omega_prev - max_step, self.omega_prev + max_step)
        self.omega_prev = omega

        v = max(self.v_min, self.v_forward)  # 满速
        tw = Twist()
        tw.linear.x = v
        tw.angular.z = omega
        return tw

    # ====== MICRO_SHIFT ======
    def _enter_micro_shift(self, trigger="enter"):
        # side sign: right more(+)-> 左移(+)；left more(-)-> 右移(-)
        self.ms_dir = 1 if self.side_delta > 0 else -1
        # side_scale: 映射 |side_delta|∈[0,1] → [min_scale, 1]
        scale = clip(abs(self.side_delta), 0.0, 1.0)
        self.ms_side_scale = clip(self.ms_min_scale + (1.0 - self.ms_min_scale) * scale, self.ms_min_scale, 1.0)
        # 强度与时间
        self.ms_omega = self.ms_omega_base * self.ms_side_scale
        dur_scale = 0.6 + 0.4 * self.ms_side_scale
        self.ms_turn_dur = self.ms_turn_base * dur_scale
        self.ms_straight_dur = self.ms_straight_base * dur_scale

        self.mode = "MICRO_SHIFT"
        self.ms_phase = "TURN1"
        self.ms_t0 = self.get_clock().now()
        self.ms_cycles = 0
        self.omega_prev *= 0.3

    def _enter_track(self):
        self.mode = "TRACK"
        self.ms_phase = "TURN1"
        self.omega_prev *= 0.3

    def _phase_t(self):
        return (self.get_clock().now() - self.ms_t0).nanoseconds * 1e-9

    def _set_phase(self, name):
        self.ms_phase = name
        self.ms_t0 = self.get_clock().now()

    def _early_exit_needed(self):
        """实时打断条件：side 变号、side 明显下降、sym/信心恢复。"""
        if (self.side_delta * self.ms_dir) < 0:  # 变号
            return "flip"
        if abs(self.side_delta) <= self.ms_early_side_drop:
            return "ok"
        if (abs(self.lat_f) <= self.ms_ok_sym and self.conf >= self.ms_ok_conf):
            return "ok"
        return None

    def _step_micro_shift(self, dt):
        v = max(self.v_min, self.v_forward * self.ms_v_frac)
        omega = 0.0
        t = self._phase_t()
        sign = 1.0 if self.ms_dir > 0 else -1.0  # +1 左移时 TURN1 为 CCW(+)

        # 实时自适应：每个周期刷新 scale（防止“变多/变少”后还照旧强度）
        scale = clip(abs(self.side_delta), 0.0, 1.0)
        self.ms_side_scale = clip(self.ms_min_scale + (1.0 - self.ms_min_scale) * scale, self.ms_min_scale, 1.0)
        self.ms_omega = self.ms_omega_base * self.ms_side_scale

        # 相位逻辑（可打断）
        if self.ms_phase == "TURN1":
            omega = sign * self.ms_omega   # CCW for left-shift, CW for right-shift
            ev = self._early_exit_needed()
            if ev == "flip":
                # 立即进入反向 TURN2（相当于“半轮纠偏”）
                self._set_phase("TURN2")
            elif ev == "ok" or t >= self.ms_turn_dur:
                self._set_phase("TURN2")

        elif self.ms_phase == "TURN2":
            omega = -sign * self.ms_omega
            ev = self._early_exit_needed()
            if ev == "flip":
                # 反向又反向 -> 直接进入 STRAIGHT 评估
                self._set_phase("STRAIGHT")
            elif ev == "ok" or t >= self.ms_turn_dur:
                self._set_phase("STRAIGHT")

        elif self.ms_phase == "STRAIGHT":
            omega = 0.0
            ev = self._early_exit_needed()
            if ev == "ok" or t >= self.ms_straight_dur:
                self._set_phase("EVAL")

        elif self.ms_phase == "EVAL":
            # 平衡+置信恢复 -> 退出
            if abs(self.side_delta) <= self.ms_exit_side and self.conf >= self.ms_ok_conf:
                self._enter_track()
            else:
                # 是否越界（符号与 dir 相反）？
                if (self.side_delta * self.ms_dir) < 0:
                    # 纠偏半强度
                    self._set_phase("CORR_T1")
                else:
                    # 继续下一轮
                    self.ms_cycles += 1
                    if self.ms_cycles >= self.ms_max_cycles:
                        self._enter_track()
                    else:
                        self._set_phase("TURN1")

        elif self.ms_phase == "CORR_T1":
            omega = -sign * (self.ms_omega * self.ms_corr_scale)
            ev = self._early_exit_needed()
            if ev == "ok" or t >= self.ms_corr_turn_base:
                self._set_phase("CORR_T2")

        elif self.ms_phase == "CORR_T2":
            omega = sign * (self.ms_omega * self.ms_corr_scale)
            ev = self._early_exit_needed()
            if ev == "ok" or t >= self.ms_corr_turn_base:
                self._set_phase("CORR_ST")

        elif self.ms_phase == "CORR_ST":
            omega = 0.0
            if t >= self.ms_corr_straight_base:
                self._set_phase("EVAL")

        # 限幅与加速度
        omega = clip(omega, -self.omega_limit, self.omega_limit)
        max_step = self.omega_acc_limit * dt
        omega = clip(omega, self.omega_prev - max_step, self.omega_prev + max_step)
        self.omega_prev = omega

        tw = Twist()
        tw.linear.x = v
        tw.angular.z = omega
        return tw


def main(args=None):
    rclpy.init(args=args)
    node = RowController()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == "__main__":
    main()
