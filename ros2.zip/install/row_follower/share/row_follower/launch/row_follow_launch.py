from launch import LaunchDescription
from launch.actions import ExecuteProcess
from launch_ros.actions import Node
from ament_index_python.packages import get_package_share_directory
import os

def generate_launch_description():
    pkg = get_package_share_directory('row_follower')

    world = os.path.join(pkg, 'world', 'crops.world')
    percept_yaml = os.path.join(pkg, 'row_follower/config', 'perception.yaml')
    controller_yaml = os.path.join(pkg, 'row_follower/config', 'controller.yaml')

    gz = ExecuteProcess(
        cmd=['gazebo', world, '--verbose'],
        output='screen'
    )

    perception = Node(
        package='row_follower',
        executable='perception',
        name='perception',            # matches YAML key "perception"
        output='screen',
        parameters=[percept_yaml]
    )

    controller = Node(
        package='row_follower',
        executable='controller',
        name='row_controller',        # matches YAML key "row_controller"
        output='screen',
        parameters=[controller_yaml]
    )

    return LaunchDescription([gz, perception, controller])
